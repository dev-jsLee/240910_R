# 주석(comment)
# ctrl + shift + c

# 한줄코드 실행
# ctrl + Enter

# 코드 위아래로 이동
# alt + 위아래 방향키

# 코드 위아래로 복사
# alt + shift + 위아래 방향키

# 여러줄 동시 수정
# ctrl + alt + 위아래 방향키
# 탈출키는 esc

# 한줄 지우기(delete)
# ctrl + d

# 복사,   붙여넣기, 잘라내기, undo,    redo
# ctrl+c, ctrl + v, ctrl + x, ctrl + z,ctrl+y 

# 저장
# ctrl + s

# 새로운 문서 생성(new)
# ctrl + shift + n

# 탭 이동(우측 이동)
# ctrl + Tab

# 탭 이동(좌측 이동)
# ctrl + shift + Tab

# 자동 완성
# ctrl + space bar

# 단어 찾기
# ctrl + f

# 단어 찾기(고급)
# ctrl + shift + f

# 전체 선택(all)
# ctrl + a


